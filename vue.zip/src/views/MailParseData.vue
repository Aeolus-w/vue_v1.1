<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

{% autoescape false %}

{% if maildata['maildate'] %}
Time : {{ maildata['maildate'] }} </br>
{% else %}
Time : unknow </br>
{% endif %}

{% if maildata['username'] %}
Username: {{ maildata['username'].replace('<', '&lt;').replace('>', '&gt;') }} </br>
{% else %}
Username : unknow </br>
{% endif %}

{% if maildata['password'] %}
Password : {{ maildata['password'].replace('<', '&lt;').replace('>', '&gt;') }} </br>
{% else %}
Password : unknow </br>
{% endif %}

{% if maildata['mailfrom'] %}
Mailfrom : {{ maildata['mailfrom'].replace('<', '&lt;').replace('>', '&gt;') }} </br>
{% else %}
Mailfrom : unknow </br>
{% endif %}

{% if maildata['mailto'] %}
Mailto : {{ maildata['mailto'].replace('<', '&lt;').replace('>', '&gt;') }} </br>
{% else %}
Mailto : unknow </br>
{% endif %}

{% if maildata['mailcc'] %}
Mailcc : {{ maildata['mailcc'].replace('<', '&lt;').replace('>', '&gt;').replace('\r\n', '</br>') }} </br>
{% else %}
Mailcc : 无 </br>
{% endif %}

{% if maildata['mailmessageid'] %}
MailID : {{ maildata['mailmessageid'].replace('<', '&lt;').replace('>', '&gt;') }} </br>
{% else %}
MailID : unknow </br>
{% endif %}
************************************************** </br>
{% if maildata['mailsubject'] %}
Mailsubject : {{ maildata['mailsubject'].replace('<', '&lt;').replace('>', '&gt;') }} </br>
{% else %}
Mailsubject : unknow </br>
{% endif %}
************************************************** </br>
{% if maildata['mailcontent'] %}
Mailcontent : {{ maildata['mailcontent'].replace('<', '&lt;').replace('>', '&gt;').replace('\r\n', '</br>') }} </br>
{% else %}
Mailcontent : 无 </br>
{% endif %}
************************************************** </br>
{% if maildata['attachs_dict'] %}
Mailattach : </br>
{% for filename, filedata in maildata['attachs_dict'].items() %}
    <a href="{{ url_for('maildata') }}?filename={{ filename }}&id={{ dataid }} ">{{ filename }} </a></br>
{% endfor %}
{% else %}
Mailattach : 无 </br>
{% endif %}
{% endautoescape %}
</body>
</html>